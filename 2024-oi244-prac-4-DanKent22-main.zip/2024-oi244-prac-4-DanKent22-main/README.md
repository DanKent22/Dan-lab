[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/0PKtbDyC)
[![Open in Codespaces](https://classroom.github.com/assets/launch-codespace-2972f46106e565e64193e422d61a12cf1da4916b45550586e14ef0a7c637dd04.svg)](https://classroom.github.com/open-in-codespaces?assignment_repo_id=15731513)
# OI 244 Practical Assignment Four
- Student Number: 23779411
- Practical Group: 4
- Neighbourhood: Motor City
- Total Marks Available: 35

*Warning:* this week's assignment builds on assignment two and will take you at least 4h to complete.

## Background

In this practical assignment, you will continue working on the website described below and that you started implementing in assignment two. The remainder of this background is the same as the background from that assignment.

In the 1990s, quite likely before you were born, the World Wide Web was a very different place, and in its youth, there were significantly fewer places where you could develop an online presence without being a large business. Social media had not yet been invented, and web browsers couldn't yet offer interactive content in the way that they can today. Due to the complexity of hosting their own sites, a lot of hobbyists chose to have a small personal website hosted by another provider. The largest and most famous of these providers was a company called GeoCities which offered a place for people to host sites organised approximately by topic with an index so that you could explore these sites. Remember, this was before Google! At the end of the 1990s the company was bought by Yahoo, who operated it for another decade before shutting it down in 2009. The Japanese language version of the site lasted significantly longer and was only terminated in 2019!

Your task for this week's practical is to develop a personal website for a hobby, passion, sport, or anything else that fits in one of the 29 categories, or Neighbourhoods, that GeoCities provided. To start, you will need to learn more about the 29 neighbourhoods and GeoCities as a whole on Wikipedia at https://en.wikipedia.org/wiki/Yahoo!_GeoCities. Next you can select a neighbourhood, and then a topic that falls under one of the topic areas of your neighbourhood. 

NB: You don't choose a neighbourhood and then create a web page for the neighbourhood, rather you choose a topic that you are interested in and then fit the neighbourhood to that topic. For example, if you'd like to create a web page about the popular video game *Baldur's Gate 3*, you'd select Times Square as your neighbourhood.

You will build a modern website on the topic you have chosen. If you desire, you can also incorporate some silly, but fun elements from the early web, such as marquees or blinking text.

## Assignment Instructions

1. Add your student number, practical group and neighbourhood to the top of this file.

2. [2] Start by opening your assignment two repository and copying your website from there into this repo / Codespace. Once you have done so, add these files and commit them. In the real world you would never copy these files in this way, we only do this for the academic assignment.

3. [3] Create a file `styles.css` and reference the file as an external stylesheet in each of your HTML pages. You will use only one CSS file for the whole site.

    From the next item, you will likely do these tasks iteratively and all at once. Read the whole of the rest of the assignment and work on it in a unified way.

4. [5] Modify your HTML pages to include suitable `id` and `class` attributes to make your styling easier.

5. [20] Write CSS to give your site a wholistic look and feel that is suitable for the content of the site. You need not have the most complex design in the world but you should write at least 10 rules with a minimum of 30 properties across them.

6. [5] Make further modifications to your HTML to help facilitate your design. Make Git commits that illustrate how you've changed your page over time.

7. Don't forget to save, add commit and push.
