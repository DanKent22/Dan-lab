                                                      Part 1
                                                   _____________   

I have used practical 6 to demonstrate the use of developer tools to debug code. 

Here is the starting point of the debugging process.
Screenshots/P8-1.png
The console is opened using F12 on windows.
Screenshots/P8-2.png
We make our way over to the javascript folder under page.
Screenshots/P8-3.png
We set breakpoints at line 7 and 18.
Screenshots/P8-4.png
Here the script has been paused, and alongside the pause/resume button is reload (F5), then Step Over (F10), Step into (F11), Step out (F12), and then step (F9). To the right of those control buttons is enable/disable all breakpoints, and lastly enable/disable automatic pause in case of an error.
Screenshots/P8-5.png
In the console, you can view all the errors, warnings, messages and info provided by the debugger.
Screenshots/P8-6.png



                                                      Part 2
                                                   _____________

                                       The importance of a good coding style.

The importance of an efficient coding style is rated among the basic things to consider during code development, as it enables the code to be understandable and maintainable. It ensures that the code can be used and reused with minimum misunderstanding.
Although this may appear relatively minor during the process of learning programming, establishing effective habits
This could substantially improve one's coding skills, raise the quality of outputs, and eventually reduce a lot of unnecessary stress.

Examples of such things that make for good coding style, as stated, are a naming scheme-clearly name all variables, functions, and classes-descriptive names, in other words. Not less important, consistent indentation and the discretionary use of whitespace makes the control structure of the code visually apparent.
clear. This enhances readability and keeps it easy towards logical flow within the program.

Even though good code should be self-describing, comments go a long way in explaining why
certain decisions or explaining confusing Logic. The documentation for functions and classes aids others
and your future self in understanding how your code works. Breaking down the code into more manageable,
reusable functions
Thus, it avoids including superfluous lines of code, which helps keep the codebase maintainable and updatable.
a reduced risk of errors occurring in the actual change implementation.

                                          What's wrong with ninja coding?

Ninja coding denotes overly intricate or ambiguous programming that creates more issues than it resolves.
Although this type of programming might seem dazzling to those who don't know better, it does create a number of issues:
The understanding of ninja code for professional programmers is often a problem. That may use some weird approaches, variable names unknown for others, or too simplified logic, which obscures how this code works and for what purpose.

Maintenance Issues: The rationale, as to when it would be necessary to alter or update this code, might be difficult for the developers to understand. This could be inclusive of the very author who might decide to use an earlier codebase. 
Therefore, this could result in longer maintenance periods and possibilities of new defects being introduced. 

Debugging Issues: If something goes wrong, it might be quite tricky to find out where the problem originated in such complex code. What was expected to be a quick fix often turns out to be long and annoying debugging sessions without well-organized code. 

Learning Curve for New Team Members: It is difficult to integrate new developers into the team, which involves learning a code base with many superfluous layers of complexity.

Code Duplication: Other developers who can't understand or reuse such ninja code may rewrite functionality that has already been implemented, resulting in code duplication or inconsistencies across the codebase.

Conclusion: Effective coding practices promote collaboration, readability, and maintainability. That means the code is easy to modify, extend, clear, and works, since clarity and simplicity are more important than implied cleverness. 

Therefore, developers will be able to produce more solid and reliable solutions; this approach will not only be important for the programmer himself but also raise the average productivity of the team. This fosters the exchange of information and ultimately results in software of superior quality. Therefore, an effective coding style is essential for both efficient and professional software development; it transcends mere preference or aesthetic considerations.