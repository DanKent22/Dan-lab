"use strict";

// 0 Show the message "I'm Javascript!"
    alert("I'm JavaScript!"); //Output: I'm JavaScript!

// 1 Declare variables, assign value, copy and show value using alert
    let admin;
    let username;

    username = "John";

    admin = username;

    alert(admin);

// 2 Create variable for planet name and for visitor
    let planet = "Earth";

    let currentvisitor = "John Doe";

// 3 What is the output of the script?
    let Q3name = "Ilya";

    alert( `hello ${1}` ); // Output: "hello 1"

    alert( `hello ${"name"}` ); // Output: "hello name"

    alert( `hello ${Q3name}` ); // Output: "hello Ilya"

// 4 Create a web-page that asks for a name and outputs it.
    let userInput = prompt("What is your name");

    alert(`Hello, ${userInput}!`);

// 5 What are the final values of all variables `a`, `b`, `c` and `d` after the code below?
    let Q5a = 1, Q5b = 1;

    let Q5c = ++Q5a; // Type of pre-increment, so a is incremented to 2 and c receives a value of 2
    let Q5d = Q5b++; // Type of post-increment, where d gets a value of 1 and b receives a value of 2

// 6 What are the values of `a` and `x` after the code below?
    let Q6a = 2;

    let x = 1 + (Q6a *= 2); //a is multiplied by 2 and now has a value of 4, therfore x becomes (1 + 4) = 5.
    // a =4, x =5

//7 What are results of these expressions?
    "" + 1 + 0 // = 10
    "" - 1 + 0 // = -1
    true + false // = 1
    6 / "3" // = 2
    "2" * "3" // = 6
    4 + 5 + "px" // = "9px"
    "$" + 4 + 5 // = "$45"
    "4" - 2 // = 2
    "4px" - 2 // = NaN
    "  -9  " + 5 // = "  -9  5"
    "  -9  " - 5 // = -14
    null + 1 // = 1
    undefined + 1 // = NaN
    " \t \n" - 2 // = -2

// 8 Here is some code that asks the user for two numbers and shows their sum.
    let Q8a = prompt("First number?", 1);
    let Q8b = prompt("Second number?", 2);

    alert(+Q8a + +Q8b); // 3

// 9 What will be the result for these expressions?
    5 > 4 // true
    "apple" > "pineapple" // false
    "2" > "12" // true
    undefined == null // true
    undefined === null // false
    null == "\n0\n" // false
    null === +"\n0\n" // false

// 10  Will the `alert` be shown?
if ("0") {
    alert( 'Hello' );
    } // The answer is yes, the alert will be shown

// 11 Using the `if..else` construct, write the code which asks: 'What is the "official" name of JavaScript?
     let Q11value = prompt('What is the "official" name of JavaScript?', '');

     if (Q11value == 'ECMAScript'){
        alert("Right!");
     } 
     else {
        alert("You don't know? ECMAScript!")
     }
     
// 12 Using `if..else`, write the code which gets a number via `prompt` and then shows in `alert`:
     let Q12value = prompt('Type a number', 0);

     if (Q12value > 0){
        alert( 1 );
     } else if (Q12value < 0){
        alert( -1 );
     } else {
        alert( 0 );
     }

// 13 Rewrite this `if` using the conditional operator `'?'`:

    let Q13a = 1, Q13b = 2; // Examples for A and B
    let result = ( Q13a + Q13b < 4) ? 'Below' : 'Over'; // The ? operator is called the ternary or conditional operator, and represents a shortcut for an if-else statement.
     // The methodology for the ? operator is: condition ? value_if_true : value_if_false

// 14 Rewrite `if..else` using multiple ternary operators `'?'`.
    let login = 'Employee';    
    let message = (login == 'Employee') ? 'Hello' :
    (login == 'Director') ? 'Greetings' :
    (login == '') ? 'No login' :
    message = '';

    console.log(message);
// 15 What is the code below going to output?
    alert( null || 2 || undefined );
     // Output is 2, which is the first truthy value

// 16 What will the code below output?
    alert( alert(1) || 2 || alert(3) );
    // Output is first 1, then 2

// 17 What is this code going to show?
    alert(1 && null && 2);
    // Answer is null, because it's the first falsy value found in the list

// 18 What will this code show?
    alert( alert(1) && alert(2) );
     // Anwer is 1, then undefined

// 19 What will the result be?
    alert( null || 2 && 3 || 4 );
    // Answer is 3

// 20  Write an `if` condition to check that `age` is between `14` and `90` inclusively.
    if (age >= 14 && age <= 90)

// 21 Write an `if` condition to check that `age` is NOT between `14` and `90` inclusively.
    if (!(age >= 14 && age <= 90))

// 22 Which of these `alert`s are going to execute?
    // Runs. 
    // The result of -1 || 0 = =1, and is truthy
    if (-1 || 0) alert( 'first' );

    // Dosen't run
    // -1 && 0 = 0, and is falsy
    if (-1 && 0) alert( 'second' );

    // Executes
    // Operators && has a higher precedence than ||
    // so -1 && 1 executes first, outputting the chain:
    // null || -1 && 1 -> null || 1 -> 1
    if (null || -1 && 1) alert( 'third' );

