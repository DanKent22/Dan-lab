[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/hwSJ5pQf)
[![Open in Codespaces](https://classroom.github.com/assets/launch-codespace-2972f46106e565e64193e422d61a12cf1da4916b45550586e14ef0a7c637dd04.svg)](https://classroom.github.com/open-in-codespaces?assignment_repo_id=16422605)
# OI 244 Practical Assignment Seven
- Student Number: 23779411
- Practical Group: 4
- Total Marks Available: 65

## Instructions

Complete the below exercises by creating new files in this repository. You should commit your changes with an appropriate message after you complete each exercise. You should create a single `index.htm` file that includes a single `.js` file using a `<script>` tag, then answering each of the numbered questions using either code or comments in the `.js` file. Make it clear which question is which by inserting comments seperating the questions.

Many of these exercises ask you to simply interpret code and record the answer. You can test your thinking by executing the code, but you should first perform the thought exercise. Each excercise is very simple, and this practical can be completed quickly, but *ensure* that you understand each of the answers. You comments for questions where you simply record the answer.


The questions for this practical are taken from the "Tasks" in sections 13-17 from the JavaScript Fundamentals on JavaScript.info, you can find the solution to each exercise in the various sections at https://javascript.info/first-steps, if needed.

## Questions

1. [1] What is the last value alerted by this code? Why?

    ```js
    let i = 3;

    while (i) {
        alert( i-- );
    }
    ```

2. [4] For every loop iteration, write down which value it outputs and then compare it with the solution.

    Both loops `alert` the same values, or not?

    a. The prefix form `++i`:

    ```js
    let i = 0;
    while (++i < 5) alert( i );
    ```
    b. The postfix form `i++`

    ```js
    let i = 0;
    while (i++ < 5) alert( i );
    ```

3. [4] For each loop write down which values it is going to show. Then compare with the answer.

    Both loops `alert` same values or not?

    a. The postfix form:

    ```js
    for (let i = 0; i < 5; i++) alert( i );
    ```

    b. The prefix form:

    ```js
    for (let i = 0; i < 5; ++i) alert( i );
    ```

4. [4] Use the `for` loop to output even numbers from `2` to `10`.

5. [4] Rewrite the code changing the `for` loop to `while` without altering its behavior (the output should stay same).

    ```js run
    for (let i = 0; i < 3; i++) {
    alert( `number ${i}!` );
    }
    ```

6. [4] Write a loop which prompts for a number greater than `100`. If the visitor enters another number -- ask them to input again.

    The loop must ask for a number until either the visitor enters a number greater than `100` or cancels the input/enters an empty line.

    Here we can assume that the visitor only inputs numbers. There's no need to implement a special handling for a non-numeric input in this task.

7. [8] An integer number greater than `1` is called a [prime](https://en.wikipedia.org/wiki/Prime_number) if it cannot be divided without a remainder by anything except `1` and itself.

    In other words, `n > 1` is a prime if it can't be evenly divided by anything except `1` and `n`.

    For example, `5` is a prime, because it cannot be divided without a remainder by `2`, `3` and `4`.

    **Write the code which outputs prime numbers in the interval from `2` to `n`.**

    For `n = 10` the result will be `2,3,5,7`.

    P.S. The code should work for any `n`, not be hard-tuned for any fixed value.

8. [6] Write the code using `if..else` which would correspond to the following `switch`:

    ```js
    switch (browser) {
    case 'Edge':
        alert( "You've got the Edge!" );
        break;

    case 'Chrome':
    case 'Firefox':
    case 'Safari':
    case 'Opera':
        alert( 'Okay we support these browsers too' );
        break;

    default:
        alert( 'We hope that this page looks ok!' );
    }
    ```

9. [4] Rewrite the code below using a single `switch` statement:

    ```js run
    let a = +prompt('a?', '');

    if (a == 0) {
    alert( 0 );
    }
    if (a == 1) {
    alert( 1 );
    }

    if (a == 2 || a == 3) {
    alert( '2,3' );
    }
    ```

10. [2] The following function returns `true` if the parameter `age` is greater than `18`.

    Otherwise it asks for a confirmation and returns its result:

    ```js
    function checkAge(age) {
    if (age > 18) {
        return true;
    *!*
    } else {
        // ...
        return confirm('Did parents allow you?');
    }
    */!*
    }
    ```

    Will the function work differently if `else` is removed?

    ```js
    function checkAge(age) {
    if (age > 18) {
        return true;
    }
    *!*
    // ...
    return confirm('Did parents allow you?');
    */!*
    }
    ```

    Is there any difference in the behavior of these two variants?

11. [4] The following function returns `true` if the parameter `age` is greater than `18`.

    Otherwise it asks for a confirmation and returns its result.

    ```js
    function checkAge(age) {
    if (age > 18) {
        return true;
    } else {
        return confirm('Did parents allow you?');
    }
    }
    ```

    Rewrite it, to perform the same, but without `if`, in a single line.

    Make two variants of `checkAge`:

    a. Using a question mark operator `?`

    b. Using OR `||`

12. [6] Write a function `min(a,b)` which returns the least of two numbers `a` and `b`.

    For instance:

    ```js
    min(2, 5) == 2
    min(3, -1) == -1
    min(1, 1) == 1
    ```

13. [8] Write a function `pow(x,n)` that returns `x` in power `n`. Or, in other words, multiplies `x` by itself `n` times and returns the result.

    ```js
    pow(3, 2) = 3 * 3 = 9
    pow(3, 3) = 3 * 3 * 3 = 27
    pow(1, 100) = 1 * 1 * ...* 1 = 1
    ```

    Create a web-page that prompts for `x` and `n`, and then shows the result of `pow(x,n)`.

    P.S. In this task the function should support only natural values of `n`: integers up from `1`.

14. [6] Replace Function Expressions with arrow functions in the code below:

    ```js run
    function ask(question, yes, no) {
    if (confirm(question)) yes();
    else no();
    }

    ask(
    "Do you agree?",
    function() { alert("You agreed."); },
    function() { alert("You canceled the execution."); }
    );
    ```
