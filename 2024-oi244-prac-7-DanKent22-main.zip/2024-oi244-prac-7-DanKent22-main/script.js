"use strict";

// 1. What is the last value alerted by this code? Why?

    // The answer is 1, because the check for while(i) stops at 0.

        let i = 3;

        while (i) {
            alert( i-- );
        }

// 2. For every loop iteration, write down which value it outputs and then compare it with the solution.

    // a shows from 1 to 4, b shows from 1 to 5.
        
        //   a. The prefix form `++i`:
        let Q2i = 0;
        while (++i < 5) alert( i );

        // b. The postfix form `i++`
        let Q2i = 0;
        while (i++ < 5) alert( i );

// 3. For each loop write down which values it is going to show. Then compare with the answer.

    // For both a and b, the answer is 0 to 4.

        // a. The postfix form:
        for (let i = 0; i < 5; i++) alert( i );

        //  b. The prefix form:
        for (let i = 0; i < 5; ++i) alert( i );

// 4. Use the `for` loop to output even numbers from `2` to `10`.

    //Used the "modulo operator to calculate the remainder"

        for (let i = 2; i <= 10, i++){
            if (i % 2 == 0){
                alert(i);
            }
        }

// 5. Rewrite the code changing the `for` loop to `while` without altering its behavior (the output should stay same).

    //Changed loop from For -> While

        let Q5i = 0;
        while(Q5i < 3){
                alert( `number ${Q5i}!` );
                Q5i++;
            }

// 6. Write a loop which prompts for a number greater than `100`. If the visitor enters another number -- ask them to input again.

    //Use a do-while loop

    let num;

    do {
        num = prompt(*Enter a number above 100., 0);
    } while ( num <=100 && num);

// 7. An integer number greater than `1` is called a [prime](https://en.wikipedia.org/wiki/Prime_number) if it cannot be divided without a remainder by anything except `1` and itself.
 
    let n = 10;

    nextPrime:
    for (let i = 2; i <= n; i++) { // for every n iterations of i.

    for (let j = 2; j < i; j++) { // Checking for divisor
        if (i % j == 0) continue nextPrime; // Not prime? skip to next i.
    }

    alert( i );
    }

// 8. Write the code using `if..else` which would correspond to the following `switch`:

    if (browser == 'Edge'){
        alert("You've got the edge!");
    } else if (browser == 'Chrome' 
        || browser =='Firefox' 
        || browser == 'Safari' 
        || browser == 'Opera'){
            alert('Okay we support these browsers too');
        } else {
            alert('We hope that this page looks ok (We dont know how to use viewport lol)');
        }

// 9. Rewrite the code below using a single `switch` statement:

    // First 2 checks become a single case. Check 3 becomes two cases.

    let a = +prompt('a?', '');

    switch (a){
        case 0:
            alert( 0 );
            break;

        case 1:
            alert ( 1 );
            break;

        case 2:
        case 3:
            alert( '2,3' );
            break;
    }

// 10. The following function returns `true` if the parameter `age` is greater than `18`.

    // There is no difference, the function executes exactly the same

// 11. The following function returns `true` if the parameter `age` is greater than `18`.

    // Used question mark operator

    function checkAge(age) {
        return (age > 18) ? true : confirm('Did parents allow you?');
      }

// 12. Write a function `min(a,b)` which returns the least of two numbers `a` and `b`.

    // Solved using the question mark operator again

    function min(a, b) {
        return a < b ? a : b;
      }

// 13. Write a function `pow(x,n)` that returns `x` in power `n`. Or, in other words, multiplies `x` by itself `n` times and returns the result.

    function pow(x, n) {
        let result = x;
    
        for (let i = 1; i < n; i++) {
        result *= x;
        }
    
        return result;
    }
    
    let x = prompt("x?", '');
    let n = prompt("n?", '');
    
    if (n < 1) {
        alert(`Power ${n} is not supported, use a positive integer`);
    } else {
        alert( pow(x, n) );
    }

// 14. Replace Function Expressions with arrow functions in the code below:

    function ask(question, yes, no) {
        if (confirm(question)) yes();
        else no();
    }
    
    ask(
        "Do you agree?",
        () => alert("You agreed."),
        () => alert("You canceled the execution.")
    );